package com.my.workflow.action;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.opensymphony.xwork2.ActionSupport;

@Results({
	@Result(name="success", type="redirect", location="/initialize")
})
public class DefaultAction extends ActionSupport {

	private static final long serialVersionUID = 8054331775051286775L;
	
	@Action("/")
	public String defaultAction(){
		return SUCCESS;
	}

}
