package com.my.workflow.action;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.InterceptorRefs;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.my.workflow.model.Project;
import com.my.workflow.model.User;
import com.my.workflow.model.WorkFlow;
import com.my.workflow.service.WorkFlowService;
import com.opensymphony.xwork2.ActionSupport;

@Namespace("/")
@Results({ @Result(name = "success", location = "/flow.jsp") })
@InterceptorRefs(value = {
		@InterceptorRef(value = "scope", params = { "session", "user, project, workFlow", "key", "flow" }),
		@InterceptorRef(value = "defaultStack") })
public class WorkFlowAction extends ActionSupport {

	private static final long serialVersionUID = 1675884592053565011L;

	@Autowired
	private WorkFlowService workFlowService;

	@Action("selectWorkFlow")
	public String selectProject() {
		workFlow = workFlowService.getWorkFlowById(project, workFlowId);
		return SUCCESS;
	}

	private int workFlowId = 1;

	private User user;
	private Project project;
	private WorkFlow workFlow;

	public int getWorkFlowId() {
		return workFlowId;
	}

	public void setWorkFlowId(int workFlowId) {
		this.workFlowId = workFlowId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public WorkFlow getWorkFlow() {
		return workFlow;
	}

	public void setWorkFlow(WorkFlow workFlow) {
		this.workFlow = workFlow;
	}

}
