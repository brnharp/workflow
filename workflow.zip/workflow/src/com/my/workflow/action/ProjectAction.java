package com.my.workflow.action;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.InterceptorRefs;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.my.workflow.model.Project;
import com.my.workflow.model.User;
import com.my.workflow.service.ProjectService;
import com.opensymphony.xwork2.ActionSupport;

@Namespace("/")
@Results({ @Result(name = "success", location = "/project.jsp") })
@InterceptorRefs(value = { @InterceptorRef(value = "scope", params = { "session", "user, project", "key", "flow" }),
		@InterceptorRef(value = "defaultStack") })
public class ProjectAction extends ActionSupport {

	private static final long serialVersionUID = 1675884592053565011L;

	@Autowired
	private ProjectService projectService;

	@Action("selectProject")
	public String selectProject() {
		project = projectService.getProjectById(user, projectId);
		return SUCCESS;
	}

	private User user;
	private int projectId = 1;
	private Project project;

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}
