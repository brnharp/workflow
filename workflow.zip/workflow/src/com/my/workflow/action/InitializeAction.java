package com.my.workflow.action;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.InterceptorRefs;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.my.workflow.model.User;
import com.my.workflow.service.UserService;
import com.opensymphony.xwork2.ActionSupport;

@Namespace("/")
@Results({ @Result(name = "success", location = "/home.jsp") })
@InterceptorRefs(value = { @InterceptorRef(value = "scope", params = { "session", "user", "key", "flow" }),
		@InterceptorRef(value = "defaultStack") })
public class InitializeAction extends ActionSupport {

	private static final long serialVersionUID = 1675884592053565011L;

	@Autowired
	private UserService userService;

	@Action("initialize")
	public String initializeWorkFlow() {
		user = userService.getUserWithProjects(1);
		return SUCCESS;
	}

	private User user;

	public UserService getUserService() {
		return userService;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getUser() {
		return user;
	}

}
