package com.my.workflow.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.sql.ResultSetMetaData;
import javax.sql.DataSource;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * A collection of database oriented utilities.
 */

/**
 * Created by IntelliJ IDEA.
 * User: JASON_POWELL
 * Date: May 13, 2008
 * Time: 10:48:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class DatabaseUtility {
	final static Logger logger = LogManager.getFormatterLogger(DatabaseUtility.class);

    /**
     * Constructor
     */
    public DatabaseUtility() {


    }


    /**
     * Gets a connection from the data source.
     * @param ds
     * @param autoCommit
     * @return connection
     */
    public static Connection getConnection(DataSource ds) throws SQLException {
        Connection conn = null;
        StopWatch debugTimer = null;
        try {
            if (logger.isTraceEnabled()) {
                debugTimer = new StopWatch();
                debugTimer.start();
            }

            conn = ds.getConnection();

        } catch (SQLException e) {
            logger.error("DataSource.getConnection failed. Reason: " + e.getMessage());
            throw new SQLException("New database connection unavailable", e);
        } finally {
            if (logger.isTraceEnabled() && debugTimer != null) {
                debugTimer.stop();
                logger.trace(String.format("getConnection execution time: %s", debugTimer));
            }
        }

        return conn;
    }


    /**
     * Closes a prepared statement logging a warning if a SQLException is encountered.
     * <p/>
     * <p>Use of this version of close eliminates the need for verbose try/catch logic
     * to handle the SQLException.
     */
    public static void close(PreparedStatement pStmt) {
        if (pStmt == null) {
            return;
        }

        logger.trace("Closing PreparedStatement");

        try {
            pStmt.close();
        }
        catch (SQLException e) {
            logger.warn("Error closing prepared statement. ");
        } finally {
            pStmt = null;
        }
    }

    /**
     * Closes a statement logging a warning if a SQLException is encountered.
     * <p/>
     * <p>Use of this version of close eliminates the need for verbose try/catch logic
     * to handle the SQLException.
     */
    public static void close(Statement stmt) {
        if (stmt == null) {
            return;
        }

        logger.trace("Closing Statement");

        try {
            stmt.close();
        }
        catch (SQLException e) {
            logger.warn("Error closing statement. ");
        } finally {
            stmt = null;
        }
    }

    /**
     * Closes a callable statement logging a warning if a SQLException is encountered.
     * <p/>
     * <p>Use of this version of close eliminates the need for verbose try/catch logic
     * to handle the SQLException.
     */
    public static void close(CallableStatement cStmt) {
        if (cStmt == null) {
            return;
        }

        logger.trace("Closing CallableStatement");

        try {
            cStmt.close();
        }
        catch (SQLException e) {
            logger.warn("Callable statement close error. ");
        } finally {
            cStmt = null;
        }
    }

    /**
     * Closes a result set logging a warning if a SQLException is encountered.
     * <p/>
     * <p>Use of this version of close eliminates the need for verbose try/catch logic
     * to handle the SQLException.
     */
    public static void close(ResultSet rs) {
        if (rs == null) {
            return;
        }

        logger.trace("Closing ResultSet");

        try {
            rs.close();
        }
        catch (SQLException e) {
            logger.warn("ResultSet close error. ");
        } finally {
            rs = null;
        }
    }

    /**
     * Closes a database Connection logging a warning if a SQLException is encountered.
     * <p/>
     * <p>Use of this version of close eliminates the need for verbose try/catch logic
     * to handle the SQLException.
     */
    public static void close(Connection conn) {
        if (conn == null) {
            return;
        }

        logger.trace("Closing Connection");

        try {
            if (!conn.isClosed()) {
                conn.close();
            }
        }
        catch (SQLException e) {
            logger.warn("Connection close error. ");
        } finally {
            conn = null;
        }
    }


    /**
     * Converts a java.sql.Timestamp to a java.util.Date.
     * <p/>
     * <p>Null arguments generate an IllegalArgumentException.
     *
     * @param ts
     * @return Date
     */
    public static java.util.Date convertTimestampToUtilDate(Timestamp ts) {
        if (ts == null) {
            throw new IllegalArgumentException("Null timestamp not allowed.");
        }
        return new java.util.Date(ts.getTime());
    }

    /**
     * Converts a java.util.Date to a java.sql.Timestamp.
     * <p/>
     * <p>Null arguments generate an IllegalArgumentException.
     *
     * @param date
     * @return Timestamp
     */
    public static Timestamp convertUtilDateToTimestamp(java.util.Date date) {
        if (date == null) {
            throw new IllegalArgumentException("Null timestamp not allowed.");
        }
        return new Timestamp(date.getTime());
    }

    /**
     * Provides a java.sql.Timestamp set to the current ssytem time.
     *
     * @return Timestamp Current
     */
    public static Timestamp getCurrentTimestamp() {
        return convertUtilDateToTimestamp(new java.util.Date());
    }


    /**
     * Rolls back a database transaction logging a warning if a SQLException is encountered.
     * <p/>
     * <p>Use of this version of rollback eliminates the need for verbose try/catch logic
     * to handle the SQLException.
     *
     * @since 0.5
     */
    public static void rollback(Connection dbConnection) {
        if (dbConnection != null) {
            try {
                dbConnection.rollback();
            } catch (SQLException e) {
                logger.warn("Rollback error. " + e.getMessage());
            }
        }
    }


    /**
     * Closes a JDBC-related object logging a warning if a SQLException is encountered.
     * <p/>
     * <p>Use of this version of close eliminates the need for verbose try/catch logic
     * to handle the SQLException.
     * <p/>
     * <p>This method will generate an IllegalArgumentException if the object passed isn't
     * one of the following classes in java.sql:  PreparedStatement, Statement, ResultSet,
     * CallableStatement, or Connection.
     *
     * @since 0.5
     */
    private static void _close(Object dbObj) {

        if (dbObj != null) {
            if (dbObj instanceof PreparedStatement) {
                close((PreparedStatement) dbObj);
            } else if (dbObj instanceof Statement) {
                close((Statement) dbObj);
            } else if (dbObj instanceof ResultSet) {
                close((ResultSet) dbObj);
            } else if (dbObj instanceof CallableStatement) {
                close((CallableStatement) dbObj);
            } else if (dbObj instanceof Connection) {
                close((Connection) dbObj);
            } else {
                throw new IllegalArgumentException("Invalid JDBC type: " + dbObj.getClass().getCanonicalName());
            }
        }
    }


    /**
     * Closes JDBC objects in a safe order.
     * @param objects   one or more JDBC objects.
     */
    public static void close(Object ... objects) {
        List<Object> aList = new ArrayList<Object>();
        List<Object> bList = new ArrayList<Object>();
        List<Object> cList = new ArrayList<Object>();

        for (Object o : objects) {
            if (o != null) {
                if (o instanceof ResultSet) {
                    aList.add(o);
                } else if (o instanceof Statement || o instanceof PreparedStatement || o instanceof CallableStatement) {
                    bList.add(o);
                } else if (o instanceof Connection) {
                    cList.add(o);
                } else {
                    // else only warn...
                    logger.warn("Request to close unknown object skipped: " + o.getClass().getCanonicalName());
                }
            }
        }

        for (Object o : aList) {
            _close(o);
        }

        for (Object o : bList) {
            _close(o);
        }

        for (Object o : cList) {
            _close(o);
        }

    }

    /**
     * Deregisters JDBC drivers in this context's ClassLoader.
     * Call only after stopping tasks that use the driver(s).
     */
    public static void deregisterDbDrivers() {
        // Get the webapp's ClassLoader
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        // Loop through all drivers
        Enumeration<Driver> drivers = DriverManager.getDrivers();
        while (drivers.hasMoreElements()) {
            Driver driver = drivers.nextElement();
            if (driver.getClass().getClassLoader() == cl) {
                // This driver was registered by the webapp's ClassLoader, so deregister it:
                try {
                    logger.debug(String.format("Deregistering JDBC driver %s", driver));
                    DriverManager.deregisterDriver(driver);
                } catch (SQLException ex) {
                    logger.error(String.format("Error deregistering JDBC driver %s", driver));
                }
            } else {
                // driver was not registered by the webapp's ClassLoader and may be in use elsewhere
                logger.debug(String.format("Not deregistering JDBC driver %s as it does not belong to this webapp's ClassLoader", driver));
            }
        }
    }
    
    public static boolean hasColumn(ResultSet rs, String columnName) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columns = rsmd.getColumnCount();
        for (int x = 1; x <= columns; x++) {
            if (columnName.equalsIgnoreCase(rsmd.getColumnName(x))) {
                return true;
            }
        }
        return false;
    }
}
