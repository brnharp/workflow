package com.my.workflow.dao;

import java.util.List;

import com.my.workflow.model.WorkFlow;

public interface WorkFlowDao {
	
	public List<WorkFlow> getProjectWorkFlows(int project_id);

}
