package com.my.workflow.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.my.workflow.dao.ProjectDao;
import com.my.workflow.enums.Status;
import com.my.workflow.model.Project;
import com.my.workflow.util.DatabaseUtility;

@Service("projectDao")
public class ProjectDaoImpl implements ProjectDao {
	
	@Autowired
	private DataSource dataSource;

	private static String USER_PROJECTS = "select pr.id, pr.name, pr.description, up.status from workflow.project pr "
			+"join workflow.user_project up on pr.id = up.project_id "
			+"where up.user_id = ?";
	@Override
	public List<Project> getUserProjects(int userId) {
		List<Project> projects = new ArrayList<Project>();;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = dataSource.getConnection();
			pstmt = con.prepareStatement(USER_PROJECTS);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while(rs.next()){
				Project project = new Project();
				project.setId(rs.getInt("id"));
				project.setName(rs.getString("name"));
				project.setDescription(rs.getString("description"));
				project.setStatus(Status.fromInt(rs.getInt("status")));
				projects.add(project);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtility.close(rs, pstmt, con);
		}
		return projects;
	}

}
