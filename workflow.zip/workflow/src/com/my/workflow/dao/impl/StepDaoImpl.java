package com.my.workflow.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.my.workflow.dao.StepDao;
import com.my.workflow.enums.Status;
import com.my.workflow.model.Step;
import com.my.workflow.util.DatabaseUtility;

@Repository("stepDao")
public class StepDaoImpl implements StepDao {

	@Autowired
	private DataSource dataSource;

	private static String STEPS_FOR_WORKFLOW = "Select st.id, st.name, st.description, fs.status "
			+ "from workflow.step st "
			+ "join workflow.flow_step fs on st.id = fs.step_id "
			+ "where fs.flow_id = ?";

	@Override
	public List<Step> getStepsForWorkFlow(int flow_id) {
		List<Step> steps = new ArrayList<Step>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = dataSource.getConnection();
			pstmt = con.prepareStatement(STEPS_FOR_WORKFLOW);
			pstmt.setInt(1, flow_id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Step step = new Step();
				step.setId(rs.getInt("id"));
				step.setName(rs.getString("name"));
				step.setDescription(rs.getString("description"));
				step.setStatus(Status.fromInt(rs.getInt("status")));
				steps.add(step);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtility.close(rs, pstmt, con);
		}
		return steps;
	}

}
