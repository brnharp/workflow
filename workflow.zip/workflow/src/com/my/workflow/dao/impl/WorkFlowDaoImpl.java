package com.my.workflow.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.my.workflow.dao.WorkFlowDao;
import com.my.workflow.enums.Status;
import com.my.workflow.model.WorkFlow;
import com.my.workflow.util.DatabaseUtility;

@Repository("workFlowDao")
public class WorkFlowDaoImpl implements WorkFlowDao {

	@Autowired
	private DataSource dataSource;

	private static String PROJECT_WORKFLOWS = "SELECT FL.ID, FL.NAME, FL.DESCRIPTION, PF.STATUS "
			+ "FROM WORKFLOW.FLOW FL " + "JOIN WORKFLOW.PROJECT_FLOW PF ON FL.ID = PF.FLOW_ID "
			+ "WHERE PF.PROJECT_ID = ?";

	@Override
	public List<WorkFlow> getProjectWorkFlows(int project_id) {
		List<WorkFlow> flows = new ArrayList<WorkFlow>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = dataSource.getConnection();
			pstmt = con.prepareStatement(PROJECT_WORKFLOWS);
			pstmt.setInt(1, project_id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				WorkFlow flow = new WorkFlow();
				flow.setId(rs.getInt("id"));
				flow.setName(rs.getString("name"));
				flow.setDescription(rs.getString("description"));
				flow.setStatus(Status.fromInt(rs.getInt("status")));
				flows.add(flow);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtility.close(rs, pstmt, con);
		}
		return flows;
	}

}
