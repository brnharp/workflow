package com.my.workflow.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.my.workflow.dao.UserDao;
import com.my.workflow.model.User;
import com.my.workflow.util.DatabaseUtility;

@Repository("userDao")
public class UserDaoImpl implements UserDao {
	
	@Autowired
	private DataSource dataSource;

	@Override
	public User getUser(int id) {
		User user = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "Select id, name from workflow.users where id = ? ";
		try {
			con = dataSource.getConnection();
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()){
				user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtility.close(rs, pstmt, con);
		}
		return user;
	}

}
