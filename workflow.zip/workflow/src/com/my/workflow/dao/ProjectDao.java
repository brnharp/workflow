package com.my.workflow.dao;

import java.util.List;

import com.my.workflow.model.Project;

public interface ProjectDao {

	public List<Project> getUserProjects(int userId);

}
