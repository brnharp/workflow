package com.my.workflow.dao;

import java.util.List;

import com.my.workflow.model.Step;

public interface StepDao {

	public List<Step> getStepsForWorkFlow(int flow_id);

}
