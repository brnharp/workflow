package com.my.workflow.dao;

import com.my.workflow.model.User;

public interface UserDao {
	
	public User getUser(int id);

}
