package com.my.workflow.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.my.workflow.dao.UserDao;
import com.my.workflow.model.User;
import com.my.workflow.service.ProjectService;
import com.my.workflow.service.UserService;

@Service("userService")
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userDao;
	@Autowired
	private ProjectService projectService;

	@Override
	public User getUser(int id) {
		return userDao.getUser(id);
	}
	
	@Override
	public User getUserWithProjects(int id) {
		User user = userDao.getUser(id);
		user.setProjectList(projectService.getUserProjects(id));
		return user;
	}

}
