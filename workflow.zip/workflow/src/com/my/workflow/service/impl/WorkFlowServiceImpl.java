package com.my.workflow.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.my.workflow.dao.WorkFlowDao;
import com.my.workflow.model.Project;
import com.my.workflow.model.WorkFlow;
import com.my.workflow.service.StepService;
import com.my.workflow.service.WorkFlowService;

@Service("workFlowService")
public class WorkFlowServiceImpl implements WorkFlowService {

	@Autowired
	private WorkFlowDao workFlowDao;
	@Autowired
	private StepService stepService;

	@Override
	public List<WorkFlow> getProjectWorkFlows(int project_id) {
		List<WorkFlow> flows = workFlowDao.getProjectWorkFlows(project_id);
		for (WorkFlow flow : flows) {
			flow.setStepList(stepService.getStepsForWorkFlow(flow.getId()));
		}
		return flows;
	}

	@Override
	public WorkFlow getWorkFlowById(Project project, int workFlowId) {
		if (project != null) {
			List<WorkFlow> flows = project.getWorkFlowList();
			for (WorkFlow f : flows) {
				if (f.getId() == workFlowId) {
					return f;
				}
			}
		}
		return null;
	}

}
