package com.my.workflow.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.my.workflow.dao.StepDao;
import com.my.workflow.model.Step;
import com.my.workflow.service.StepService;

@Service("stepService")
public class StepServiceImpl implements StepService {
	
	@Autowired
	private StepDao stepDao;

	@Override
	public List<Step> getStepsForWorkFlow(int flow_id) {
		return stepDao.getStepsForWorkFlow(flow_id);
	}

}
