package com.my.workflow.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.my.workflow.dao.ProjectDao;
import com.my.workflow.model.Project;
import com.my.workflow.model.User;
import com.my.workflow.service.ProjectService;
import com.my.workflow.service.WorkFlowService;

@Service("projectService")
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectDao projectDao;
	@Autowired
	private WorkFlowService workFlowService;

	@Override
	public List<Project> getUserProjects(int userId) {
		List<Project> projects = projectDao.getUserProjects(userId);
		for (Project project : projects) {
			project.setWorkFlowList(workFlowService.getProjectWorkFlows(project.getId()));
		}
		return projects;
	}

	@Override
	public Project getProjectById(User user, int projectId) {
		if (user != null) {
			List<Project> projects = user.getProjectList();
			for (Project p : projects) {
				if (p.getId() == projectId) {
					return p;
				}
			}
		}
		return null;
	}

}
