package com.my.workflow.service;

import java.util.List;

import com.my.workflow.model.Project;
import com.my.workflow.model.User;

public interface ProjectService {

	public List<Project> getUserProjects(int userId);

	public Project getProjectById(User user, int projectId);

}
