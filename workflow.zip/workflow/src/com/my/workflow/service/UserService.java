package com.my.workflow.service;

import com.my.workflow.model.User;

public interface UserService {

	public User getUser(int id);

	public User getUserWithProjects(int id);

}
