package com.my.workflow.service;

import java.util.List;

import com.my.workflow.model.Step;

public interface StepService {

	public List<Step> getStepsForWorkFlow(int flow_id);

}
