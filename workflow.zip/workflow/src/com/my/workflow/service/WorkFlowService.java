package com.my.workflow.service;

import java.util.List;

import com.my.workflow.model.Project;
import com.my.workflow.model.WorkFlow;

public interface WorkFlowService {

	public List<WorkFlow> getProjectWorkFlows(int project_id);

	public WorkFlow getWorkFlowById(Project project, int workFlowId);

}
