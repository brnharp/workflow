package com.my.workflow.enums;

public enum StepType {

	CALL(0), DOCUMENT(1), EMAIL(2), FILE_TRANSFER(3), MEETING(4), WAITING(5);

	private int value;

	private StepType(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
