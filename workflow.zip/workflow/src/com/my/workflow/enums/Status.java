package com.my.workflow.enums;

public enum Status {

	NOT_STARTED(0), STARTED(1), COMPLETED(2), SKIPPED(3);

	private int id;

	private Status(int id) {
		this.id = id;
	}
	
	public static Status fromInt(int id){
		for(Status status : Status.values()){
			if(status.getId() == id){
				return status;
			}
		}
		return null;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


}
